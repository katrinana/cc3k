#include <iostream>
#include <string>
#include "print.h"
#include "random.h"
#include "player.h"
#include "object.h"
#include "floor.h"
#include "drow.h"
#include "goblin.h"
#include "shade.h"
#include "vampire.h"
#include "troll.h"
using namespace std;


int main(){
	//bool end = false;
	//bool win = false;
	srand(time(0));
	bool raceset = false;
	bool gameover = false;
	
	string action = "";
	Player* p = NULL;
	
	char** map=NULL;
	string garbage;
	string command;
	
	map = mapinit(); // inilize map
	
	system("clear");
	printstart();
	cout << "enter anything to continue!" << endl;
	cin >> garbage;
	system("clear");
	printauthor();
	cout << "enter anything to continue!" << endl;
	cin >> garbage;
	system("clear");
	printcommands();
	cout << "enter anything to continue!" << endl;
	cin >> garbage;
	system("clear");
	printselect();
	
	while(cin >> command){
		bool vaild = false;
		action = "";
			
		while (raceset == false){// select race
			if (p != NULL) p = NULL;
			if (cin.eof()) break;
			
			if (command == "q"){
				gameover = true;
				break;
			}if(command == "d"){
				raceset = true;
				p = new Drow(map);
			}if(command == "g"){
				raceset = true;
				p = new Goblin(map);
			}if(command == "s"){
				raceset = true;
				p = new Shade(map);
			}if(command == "t"){
				raceset = true;
				p = new Troll(map);
			}if(command == "v"){
				raceset = true;
				p = new Vampire(map);
			}if(raceset){
				system("clear");
				p->Display("");
			}else{
				cin >> command;
			}	
		}
		
		if (gameover) break;
		
		if(!p->islose() && !p->iswon()){
			if(command=="no" || command=="so" || command=="ea" || command=="we" || 
				command=="ne" || command=="nw"|| command=="se" || command=="sw"){
					vaild = true;
					action = p->move(command);
				}
		}if(command=="l"){
			system("clear");
			printcommands();
		}if(command=="r"){
			raceset = false;
			p=NULL;
			system("clear");
			printselect();
		}if(command == "q"){
			break;
			//print action
		}
		if(p!=NULL && p->islose()){
			system("clear");
			printlose();
			p->printscore();
			cout<<endl;
			
		}if(p!= NULL && p->iswon()){
			system("clear");
			printwin();
			p->printscore();
			cout<<endl;
		} if(vaild){
			//action = action + p->Enemymove();
			system("clear");
			p->Display(action);
		}	
	}
	//delete p;
}