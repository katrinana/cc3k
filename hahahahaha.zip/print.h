#ifndef __PRINT_H__
#define __PRINT_H__

#include <iostream>
#include <string>


void printstart();

void printauthor();

void printselect();

void printwin();

void printlose();

void printcommands();

//void printinstruction();

#endif
