#include "race.h"
using namespace std;


Race::Race(char** maps):Player(maps){}

Race::~Race(){};