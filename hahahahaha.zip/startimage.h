#ifndef __STRATIMAGE_H__
#define __STRATIMAGE_H__

extern char start[17][46];