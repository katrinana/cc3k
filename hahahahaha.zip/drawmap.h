#ifndef __DRAWMAP__H_
#define __DRAWMAP__H_

extern char map[25][80];